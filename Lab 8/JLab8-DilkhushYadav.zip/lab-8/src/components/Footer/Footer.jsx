import "./footer.css"
const Footer = () => {
    return (
      <footer>
        <p>&copy; HTTP5211, 2022.</p>
      </footer>
    );
  };
  
  export default Footer;
  